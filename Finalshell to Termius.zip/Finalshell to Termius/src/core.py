"""
FinalshellDecoderX — shared core library.

Pure functions for detecting FinalShell directories, parsing connection
configuration files, and decrypting stored passwords / private keys.
"""
from __future__ import annotations

import base64
import hashlib
import os
import re
import struct
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class ServerCredential:
    """Parsed representation of a single FinalShell connection entry."""

    file_name: str
    id: str = ""
    name: str = ""
    host: str = ""
    port: int = -1
    user_name: str = ""
    authentication_type: int = -1

    # Raw (encrypted) fields as stored in JSON
    encrypted_password: str = ""
    secret_key_id: str = ""
    encrypted_private_key: str = ""

    # Decrypted values (populated after parsing)
    decoded_password: Optional[str] = None
    decoded_private_key: Optional[str] = None

    # Display helpers (computed)
    auth_mode: str = ""
    credential_display: str = ""


# ---------------------------------------------------------------------------
# Filesystem detection
# ---------------------------------------------------------------------------


def is_final_shell_dir(base_dir: Optional[Path]) -> bool:
    """Return True if *base_dir* looks like a FinalShell install directory."""
    if base_dir is None or not base_dir.is_dir():
        return False
    return (base_dir / "conn").is_dir()


def detect_final_shell_path() -> Optional[Path]:
    """Try to auto-detect the FinalShell data directory on the current OS."""
    candidates: List[Path] = []
    user_home = Path.home()

    if os.name == "nt":  # Windows
        # Check environment variable first
        finalshell_home = os.environ.get("FINALSHELL_HOME")
        if finalshell_home:
            candidates.append(Path(finalshell_home))
        
        # Current user's AppData
        candidates.append(user_home / "AppData" / "Local" / "finalshell")
        
        # Check USERPROFILE environment variable
        user_profile = os.environ.get("USERPROFILE")
        if user_profile and Path(user_profile) != user_home:
            candidates.append(Path(user_profile) / "AppData" / "Local" / "finalshell")
        
        # Program Files directories
        candidates.append(Path("C:\\Program Files\\FinalShell"))
        candidates.append(Path("C:\\Program Files (x86)\\FinalShell"))
        
        # Try to read from registry
        try:
            import winreg
            reg_paths = [
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\\FinalShell"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\\WOW6432Node\\FinalShell"),
                (winreg.HKEY_CURRENT_USER, r"SOFTWARE\\FinalShell")
            ]
            
            for hkey, reg_path in reg_paths:
                try:
                    with winreg.OpenKey(hkey, reg_path) as key:
                        install_path = winreg.QueryValueEx(key, "InstallPath")[0]
                        if install_path:
                            candidates.append(Path(install_path))
                except (FileNotFoundError, PermissionError):
                    pass
        except ImportError:
            pass
        
        # Scan all user directories as a last resort
        users_dir = Path("C:\\Users")
        if users_dir.is_dir():
            for sub in users_dir.iterdir():
                if sub.is_dir():
                    candidates.append(sub / "AppData" / "Local" / "finalshell")
                    candidates.append(sub / "AppData" / "Roaming" / "finalshell")
    
    elif sys.platform == "darwin":  # macOS
        # Check environment variable first
        finalshell_home = os.environ.get("FINALSHELL_HOME")
        if finalshell_home:
            candidates.append(Path(finalshell_home))
        
        # Standard locations
        candidates.append(user_home / "Library" / "FinalShell")
        candidates.append(user_home / "Library" / "Application Support" / "finalshell")
        candidates.append(user_home / "Applications" / "FinalShell.app" / "Contents" / "Resources")
        
        # Homebrew locations
        candidates.append(Path("/usr/local/opt/finalshell"))  # Intel
        candidates.append(Path("/opt/homebrew/opt/finalshell"))  # Apple Silicon
        
        # Flatpak/Snap locations
        candidates.append(Path("/var/lib/flatpak/app/com.finalshell.FinalShell"))
        candidates.append(Path("/snap/finalshell/current"))
        
        # Shared directory
        candidates.append(Path("/Users/Shared/FinalShell"))
    
    else:  # Linux / other
        # Check environment variable first
        finalshell_home = os.environ.get("FINALSHELL_HOME")
        if finalshell_home:
            candidates.append(Path(finalshell_home))
        
        # User directories
        candidates.append(user_home / ".finalshell")
        candidates.append(user_home / ".local/share/finalshell")
        
        # System directories
        candidates.append(Path("/opt/finalshell"))
        candidates.append(Path("/usr/share/finalshell"))
        candidates.append(Path("/usr/local/share/finalshell"))
        
        # Flatpak/Snap locations
        candidates.append(Path("/var/lib/flatpak/app/com.finalshell.FinalShell"))
        candidates.append(Path("/snap/finalshell/current"))

    # Deduplicate candidates while preserving order
    seen = set()
    unique_candidates = []
    for candidate in candidates:
        if candidate not in seen:
            seen.add(candidate)
            unique_candidates.append(candidate)

    for candidate in unique_candidates:
        if is_final_shell_dir(candidate):
            return candidate
    return None


# ---------------------------------------------------------------------------
# JSON helpers (json module based with regex fallback for non-standard JSON)
# ---------------------------------------------------------------------------


import json as json_module

def json_string(json_content: str, key: str) -> str:
    """Extract a string value for *key* from a (possibly malformed) JSON blob."""
    try:
        # Try standard JSON parsing first (faster)
        data = json_module.loads(json_content)
        return data.get(key, "")
    except json_module.JSONDecodeError:
        # Fallback to regex for malformed JSON
        pattern = re.compile(r'"' + re.escape(key) + r'"\s*:\s*"((?:\\.|[^\\"])*)"')
        m = pattern.search(json_content)
        if not m:
            return ""
        return unescape_json(m.group(1))


def json_int(json_content: str, key: str, default: int = -1) -> int:
    """Extract an integer value for *key* from a JSON blob."""
    try:
        # Try standard JSON parsing first (faster)
        data = json_module.loads(json_content)
        val = data.get(key)
        if isinstance(val, (int, float)):
            return int(val)
        return default
    except json_module.JSONDecodeError:
        # Fallback to regex for malformed JSON
        pattern = re.compile(r'"' + re.escape(key) + r'"\s*:\s*(-?\d+)')
        m = pattern.search(json_content)
        if not m:
            return default
        try:
            return int(m.group(1))
        except ValueError:
            return default


def unescape_json(s: str) -> str:
    """Process JSON escape sequences in a string."""
    if not s:
        return ""

    s = s.replace(r'\"', '"')
    s = s.replace(r'\\', '\\')
    s = s.replace(r'\/', '/')
    s = s.replace(r'\b', '\b')
    s = s.replace(r'\f', '\f')
    s = s.replace(r'\n', '\n')
    s = s.replace(r'\r', '\r')
    s = s.replace(r'\t', '\t')

    # Unicode escapes
    s = re.sub(r'\\u([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), s)
    return s


# ---------------------------------------------------------------------------
# Crypto primitives
# ---------------------------------------------------------------------------


def md5(data: bytes) -> bytes:
    """Return the MD5 digest of *data*."""
    return hashlib.md5(data).digest()


def to_signed_byte(b: int) -> int:
    """Convert an unsigned byte (0-255) to a signed byte (-128..127)."""
    return struct.unpack("b", bytes([b & 0xFF]))[0]


# ---------------------------------------------------------------------------
# LCG PRNG (Linear Congruential Generator)
# ---------------------------------------------------------------------------


class LCG_Random:
    """Python implementation of Linear Congruential Generator PRNG."""

    __slots__ = ("_seed",)
    _MULT: int = 0x5DEECE66D
    _ADDEND: int = 0xB
    _MASK: int = (1 << 48) - 1

    def __init__(self, seed: int) -> None:
        # Initialize seed: seed = (seed ^ MULT) & MASK
        # The seed is first masked to 64 bits before XOR
        seed &= (1 << 64) - 1
        self._seed = (seed ^ self._MULT) & self._MASK

    def _next(self, bits: int) -> int:
        self._seed = (self._seed * self._MULT + self._ADDEND) & self._MASK
        return self._seed >> (48 - bits)

    def next_int(self, bound: int | None = None) -> int:
        """Return a random integer. If bound is None, returns a signed 32-bit integer.
        Otherwise returns a non-negative integer less than bound.
        """
        if bound is None:
            # Unbounded: return signed 32-bit
            val = self._next(32)
            return val - (1 << 32) if val >= (1 << 31) else val

        if bound <= 0:
            raise ValueError("bound must be positive")

        # Power-of-two fast path
        if (bound & -bound) == bound:
            return (bound * self._next(31)) >> 31

        while True:
            bits = self._next(31)
            val = bits % bound
            if bits - val + (bound - 1) >= 0:
                return val

    def next_long(self) -> int:
        """Return a signed 64-bit random integer."""
        hi = self._next(32)
        lo = self._next(32)
        # Combine high and low bits into signed 64-bit value
        if lo >= (1 << 31):
            lo -= 1 << 32
        x = (hi << 32) + lo
        x &= (1 << 64) - 1
        return x - (1 << 64) if x >= (1 << 63) else x


# ---------------------------------------------------------------------------
# DES decryption
# ---------------------------------------------------------------------------


def des_decode(data: bytes, key: bytes) -> bytes:
    """DES-ECB decrypt *data* using *key* (8-byte DES key) with PKCS5 unpadding."""
    from Crypto.Cipher import DES
    from Crypto.Util.Padding import unpad

    # ranDomKey produces 16-byte MD5; DES uses only first 8 bytes
    des_key = key[:8]
    cipher = DES.new(des_key, DES.MODE_ECB)
    pt = cipher.decrypt(data)
    try:
        return unpad(pt, 8)
    except Exception:
        # If unpadding fails, return raw (may be zero-padded or unpadded)
        return pt


def ranDomKey(head: bytes) -> bytes:
    """
    Reproduce FinalShell's key-derivation algorithm from the 8-byte *head*.
    Uses LCG with parameters matching the original implementation.
    """
    # Step 1: ks = 3680984568597093857L / new Random((long)head[5]).nextInt(127)
    r1 = LCG_Random(to_signed_byte(head[5]))
    n127 = r1.next_int(127)
    if n127 == 0:
        raise ZeroDivisionError("Random.nextInt(127) returned 0")
    ks = 3680984568597093857 // n127

    # Step 2: rng = new Random(ks)
    rng = LCG_Random(ks)

    # Step 3: consume head[0] longs
    t = to_signed_byte(head[0])
    for _ in range(t if t > 0 else 0):
        rng.next_long()

    # Step 4: n = rng.nextLong()
    n = rng.next_long()

    # Step 5: r2 = new Random(n)
    r2 = LCG_Random(n)

    # Step 6: build key-data array (long values, 8 bytes each)
    ld = [
        to_signed_byte(head[4]),
        r2.next_long(),
        to_signed_byte(head[7]),
        to_signed_byte(head[3]),
        r2.next_long(),
        to_signed_byte(head[1]),
        rng.next_long(),
        to_signed_byte(head[2]),
    ]

    # Encode as big-endian 8 bytes per value
    key_data = b"".join(struct.pack(">q", val) for val in ld)
    return md5(key_data)


def decode_pass(data: str) -> Optional[str]:
    """Decrypt a FinalShell password field.

    Returns the plaintext password, or ``None`` when *data* is empty.
    """
    if not data:
        return None

    buf = base64.b64decode(data)
    head = buf[:8]
    encrypted = buf[8:]
    plain = des_decode(encrypted, ranDomKey(head))
    try:
        return plain.decode("utf-8")
    except UnicodeDecodeError:
        return plain.decode("utf-8", errors="replace")


def decode_private_key(key_data: str) -> str:
    """Base64-decode a stored private key blob."""
    return base64.b64decode(key_data).decode("utf-8")


# ---------------------------------------------------------------------------
# File loading
# ---------------------------------------------------------------------------


def load_key_data_map(config_path: Path) -> Dict[str, str]:
    """Parse ``config.json`` and return ``{id: key_data}``."""
    if not config_path.is_file():
        return {}

    key_data_map: Dict[str, str] = {}
    content = config_path.read_text(encoding="utf-8")

    try:
        # Try standard JSON parsing first
        data = json_module.loads(content)
        secret_key_list = data.get("secret_key_list", [])
        if isinstance(secret_key_list, list):
            for item in secret_key_list:
                if isinstance(item, dict):
                    id_val = item.get("id")
                    kd = item.get("key_data")
                    if id_val and kd:
                        key_data_map.setdefault(id_val, kd)
            return key_data_map
    except json_module.JSONDecodeError:
        # Fallback to regex for malformed JSON
        # Single regex pattern that handles both field orders
        key_pattern = re.compile(
            r'{[^\{\}]*?"(id|key_data)"\s*:\s*"([^"]+)"[^\{\}]*?"(key_data|id)"\s*:\s*"([^"]+)"[^\{\}]*?}',
            re.DOTALL,
        )

        for match in key_pattern.finditer(content):
            field1, val1, field2, val2 = match.groups()
            if field1 == "id" and field2 == "key_data":
                id_val, kd = unescape_json(val1), unescape_json(val2)
            elif field1 == "key_data" and field2 == "id":
                kd, id_val = unescape_json(val1), unescape_json(val2)
            else:
                continue  # Unexpected field combination, skip
            
            if id_val and kd:
                key_data_map.setdefault(id_val, kd)

    return key_data_map


def load_credentials(
    conn_dir: Path, key_data_map: Dict[str, str]
) -> List[ServerCredential]:
    """Read all ``*_connect_config.json`` files under *conn_dir*."""
    conn_files = sorted(
        (p for p in conn_dir.glob("*_connect_config.json") if p.is_file()),
        key=lambda p: p.name,
    )

    results: List[ServerCredential] = []
    for file_path in conn_files:
        content = file_path.read_text(encoding="utf-8")
        cred = parse_conn_file(file_path.name, content, key_data_map)
        results.append(cred)
    return results


def parse_conn_file(
    file_name: str, json_content: str, key_data_map: Dict[str, str]
) -> ServerCredential:
    """Parse a single connection-config JSON blob into a ServerCredential."""
    cred = ServerCredential(
        file_name=file_name,
        id=json_string(json_content, "id"),
        name=json_string(json_content, "name"),
        host=json_string(json_content, "host"),
        port=json_int(json_content, "port", -1),
        user_name=json_string(json_content, "user_name"),
        authentication_type=json_int(json_content, "authentication_type", -1),
        encrypted_password=json_string(json_content, "password"),
        secret_key_id=json_string(json_content, "secret_key_id"),
    )

    # ---- decrypt password ----
    if cred.encrypted_password:
        try:
            cred.decoded_password = decode_pass(cred.encrypted_password)
        except Exception as exc:
            cred.decoded_password = f"[密码解密失败] {exc}"

    # ---- decrypt private key ----
    if cred.secret_key_id:
        cred.encrypted_private_key = key_data_map.get(cred.secret_key_id, "")
        if cred.encrypted_private_key:
            try:
                cred.decoded_private_key = decode_private_key(cred.encrypted_private_key)
            except Exception as exc:
                cred.decoded_private_key = f"[私钥解密失败] {exc}"

    # ---- computed display fields ----
    cred.auth_mode = _build_auth_mode(cred)
    cred.credential_display = _build_credential_display(cred)
    return cred


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


def _build_auth_mode(cred: ServerCredential) -> str:
    has_pw = bool(cred.encrypted_password)
    has_key = bool(cred.secret_key_id)
    if has_pw and has_key:
        return "密码 + 密钥"
    if has_pw:
        return "账号密码"
    if has_key:
        return "公私钥"
    return "未知"


def _build_credential_display(cred: ServerCredential) -> str:
    if cred.encrypted_password:
        if cred.decoded_password:
            return cred.decoded_password
        return "[密码解密失败]"
    if cred.secret_key_id:
        return "私钥（双击复制）"
    return ""


def build_credential_copy_value(cred: ServerCredential) -> str:
    """Return the best available plaintext credential for copying."""
    if cred.encrypted_password:
        return cred.decoded_password or cred.encrypted_password
    if cred.secret_key_id:
        return cred.decoded_private_key or cred.encrypted_private_key
    return ""
