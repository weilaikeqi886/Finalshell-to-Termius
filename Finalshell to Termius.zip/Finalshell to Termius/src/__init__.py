# FinalshellDecoderX — core library
