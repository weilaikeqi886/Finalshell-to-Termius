import os
import sys
import subprocess
import re
import csv
import pandas as pd

# ==================================================
# 🚀 自动获取当前脚本所在的文件夹路径
# ==================================================
current_dir = os.path.dirname(os.path.abspath(__file__))

# 假设你的 finalshell 文件夹就在这个脚本的同级目录下
# 比如：当前文件夹/finalshell
fs_path = os.path.join(current_dir, "finalshell")

print("==================================================")
print(" 欢迎使用 FinalShell 导向 Termius 数据转换工具")
print(f"📂 当前运行目录: {current_dir}")
print(f"🔍 预设 FinalShell 路径: {fs_path}")
print("==================================================")

# 如果检测到同级目录下的 finalshell 不存在，退化为交互式输入，保证脚本100%不崩溃
if not os.path.exists(fs_path):
    print("⚠️  未在当前目录下找到 'finalshell' 文件夹。")
    while True:
        fs_path = input("📌 请手动输入或拖入你的 FinalShell 路径: ").strip()
        fs_path = fs_path.strip('"').strip("'")
        if not fs_path:
            print("❌ 路径不能为空，请重新输入。")
            continue
        if not os.path.exists(fs_path):
            print(f"❌ 找不到该路径: {fs_path}\n请检查路径是否正确！")
            continue
        break
else:
    print("✅ 已成功自动定位本地 FinalShell 文件夹！")

print("\n🚀 正在通过 CLI 引擎安全解析并抓取数据...")

stdout = ""
# 1. 调取解码引擎捕获明文
try:
    # 确保解码引擎脚本也能在当前目录下被正确找到
    decoder_script = os.path.join(current_dir, 'final_shell_decoder_cli.py')
    
    process = subprocess.Popen(
        ['python', decoder_script],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding='gbk',
        errors='ignore'
    )
    stdout, stderr = process.communicate(input=fs_path + "\n")
except Exception as e:
    print(f"❌ 后台运行失败: {e}")
    sys.exit(1)

if not stdout:
    print("❌ 提取数据失败：子进程未返回任何内容。")
    sys.exit(1)

print("📊 正在深度提取数据并严格封装为 Termius 官方 CSV 模板...")
servers = stdout.split('[')
data_list = []

for block in servers:
    if '主机:' in block or 'Host:' in block or '用户名:' in block or 'User:' in block:
        try:
            # 提取名称 (Label)
            if ']' in block:
                name = block.split(']')[1].split('\n')[0].strip()
            else:
                continue
                
            # 提取主机和端口
            host_line = re.search(r'(主机|Host):\s*(.*)', block)
            host_full = host_line.group(2).strip() if host_line else ""
            if ":" in host_full:
                host, port = host_full.rsplit(":", 1)
            else:
                host, port = host_full, "22"
                
            # 提取用户名
            user_line = re.search(r'(用户名|User):\s*(.*)', block)
            user = user_line.group(2).strip() if user_line else "root"
            
            # 提取密码
            pwd_line = re.search(r'(密码|Password):\s*(.*)', block)
            pwd = pwd_line.group(2).strip() if pwd_line else ""
            
            if pwd.lower() in ['无', 'null', 'none']:
                pwd = ""
                
            # 强力过滤换行和回车，防止破坏 CSV 行结构
            name = re.sub(r'[\r\n\t]+', '', name).strip()
            host = re.sub(r'[\r\n\t]+', '', host).strip()
            user = re.sub(r'[\r\n\t]+', '', user).strip()
            pwd = re.sub(r'[\r\n\t]+', '', pwd).strip()

            # 2. 像素级对齐上传的官方模板字段
            data_list.append({
                "Groups": "FinalShell导入",
                "Label": name,
                "Tags": "",
                "Hostname/IP": host,
                "Protocol": "ssh",
                "Port": port,
                "Username": user,
                "Password": pwd
            })
        except Exception:
            continue

# 3. 严格遵循官方模板输出为标准的 CSV 文件
if data_list:
    columns_order = ["Groups", "Label", "Tags", "Hostname/IP", "Protocol", "Port", "Username", "Password"]
    df = pd.DataFrame(data_list, columns=columns_order)
    
    # 将输出的 CSV 同样保存在当前脚本目录下
    output_name = os.path.join(current_dir, "Termius直导服务器表.csv")
    
    # 采用标准 UTF-8 编码导出
    df.to_csv(output_name, index=False, encoding='utf-8', quoting=csv.QUOTE_MINIMAL)
    
    print(f"\n✨ 官方标准 CSV 转换成功！共计完成 {len(data_list)} 条记录。")
    print(f"📂 专属直导文件已生成: {output_name}")
else:
    print("❌ 提取或转换数据失败。")